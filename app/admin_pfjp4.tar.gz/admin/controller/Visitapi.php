<?php
/**
 * Created by PhpStorm.
 * CreateTime  : 2023/10/15 20:58
 * file name : Visit.php
 * User: asusa
 * Author: Hyy-Cary
 * Contact QQ  : 373889161(.)
 * email: 373889161@qq.com
 * WeChat: 18319021313
 */


namespace app\admin\controller;


use app\admin\BaseController;
use think\facade\Config;
use think\facade\View;
use think\facade\Db;

class Visitapi extends BaseController
{
    public function index(){
        $today_start=mktime(0,0,0,date('m'),date('d'),date('Y'));
        $today_end=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
        $where = [['createTime','between',[$today_start,$today_end]]];
        $todayCount = CountTable('visit_api',$where);
        $views =  CountTable('visit_api');
        View::assign('today',$todayCount);
        View::assign('views',$views);
        return View();
    }
    public function datalist(){
        $data = request()->param();
        $size = $data['limit']?$data['limit']:10;
        $start = $data['page']?$data['page']:0;
        $where = [];
        $group = '';
        if(array_key_exists('data',$data)){
            foreach ($data['data'] as $k=>$v){
                if (empty($v['value'])) {
                    continue;
                }
                switch ($v['name']) {
                    case 'range':
                        $atime = explode(' ~ ', $v['value']);
                        if (count($atime) === 2) {
                            $st = (int)strtotime($atime[0]);
                            $et = (int)strtotime($atime[1]);
                            $where[] = ['createTime', 'between', [$st, $et]];
                        }
                        break;
                    case 'guv':
                        $group = $v['value'];
                        break;
                    default:
                        $likeValue = '%' . $v['value'] . '%';
                        $where[] = [$v['name'], 'like', $likeValue];
                }
            }
        }
        $list = pageTable('visit_api',$start,$size,$where,['id'=>'desc'],$group);
        $count = CountTable('visit_api',$where,'',$group);
        foreach ($list as &$v){
            $v['createTime'] = mac_day($v['createTime'],'color');
        }
        $arr = array('code'=>0,'msg'=>'ok','count'=>$count,'limit'=>$where,'data'=>$list);
        echo json_encode($arr);
    }
    public function delAll(){
        $id = request()->param('data');
        if(empty($id)){
            $msg = ['code'=>300,'msg'=>lang('error_column_message')];
            echo json_encode($msg);die;
        }
        $data = Db::name('visit_api')->where('id','in',$id)->select();
        if($data){
            Db::name('visit_api')->delete($id);
            $msg = ['code'=>200,'msg'=>lang('delete_message')];
        }else{
            $msg = ['code'=>300,'msg'=>lang('fail_message'),'data'=>$id];
        }
        echo json_encode($msg);
    }
    public function emptyData(){
        //截断表数据（清空表数据）
        $prefix = Config::get('database.connections.mysql.prefix');
        Db::query('truncate table '.$prefix.'visit_api');
        $msg = ['code'=>1,'msg'=>lang('wipeData')];
        echo json_encode($msg);
    }
}